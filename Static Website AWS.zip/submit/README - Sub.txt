I have changed the links with the one I have used


link: http://my-11148789842.s3-website-us-east-1.amazonaws.com
Distribution domain name: https://d69jtgtlh7tku.cloudfront.net


The figure above shows the page displayed at https://d69jtgtlh7tku.cloudfront.net

Access the website via website-endpoint, such as http://my-11148789842.s3-website-us-east-1.amazonaws.com

Access the bucket object via its S3 object URL, such as, http://my-11148789842.s3.us-east-1.amazonaws.com/index.html